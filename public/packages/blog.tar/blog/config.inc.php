<?php
namespace config;

define('DEFAULT_APP', 'home');